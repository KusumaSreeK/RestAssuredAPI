package restAssuredTests;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItems;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.qameta.allure.*;
import io.qameta.allure.restassured.AllureRestAssured;
import io.restassured.http.*;
@Epic("REST API Regression Testing using TestNG")
@Feature("Verify CRUD Operations")
	public class Task_Get_Request {
		
		@Test
		@Story("Get Request")
	    @Severity(SeverityLevel.NORMAL)
	    @Description("Test Description : Get Method To Retrieve The List Of Transactions")
		public void getMethod() {
			
			given()
			.filter(new AllureRestAssured())
				.baseUri("https://sreesumaa.herokuapp.com")
			.when()
				.get("/transactions")
			.then()
				.statusCode(200)
				.statusLine("HTTP/1.1 200 OK")
				.body("name", hasItems("Pizza Pizza"))
				.contentType(ContentType.JSON);
				
		}

	}
