package restAssuredTests;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItems;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.qameta.allure.*;
import io.qameta.allure.restassured.AllureRestAssured;
@Epic("REST API Regression Testing using TestNG")
@Feature("Verify CRUD Operations")
public class Task_Get_Request_WithSearchKeyword {

	@Test
	@Story("Get Request With Search Keyword")
    @Severity(SeverityLevel.NORMAL)
    @Description("Test Description : Get Method With Search Criteria")
	public void getMethod() {
		
		given()
		.filter(new AllureRestAssured())
			.baseUri("https://sreesumaa.herokuapp.com")
			.queryParam("keyword", "Pizza Pizza")
			.queryParam("type", "Expense")
			.queryParam("category", "Food")
		.when()
			.get("/transactions/search")
		.then()
			.statusCode(200)
			.log().all();
			
	}
}

