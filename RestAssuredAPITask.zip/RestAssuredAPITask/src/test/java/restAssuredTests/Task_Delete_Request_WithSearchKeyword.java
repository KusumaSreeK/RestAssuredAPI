package restAssuredTests;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItems;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.annotations.Test;
import io.qameta.allure.*;
import io.qameta.allure.restassured.AllureRestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
@Epic("REST API Regression Testing using TestNG")
@Feature("Verify CRUD Operations")
public class Task_Delete_Request_WithSearchKeyword {
	
	
	@Test(priority = 1)
	@Story("Delete Request")
    @Severity(SeverityLevel.NORMAL)
    @Description("Test Description : Delete Method With Correct Id In List Of Transactions")

	public void deleteMethodWithCorrectId() {
		
	try {
		Response response= 	given()
				.baseUri("https://sreesumaa.herokuapp.com")
			.when()
				.get("/transactions")
			.then()
				.statusCode(200)
				.statusLine("HTTP/1.1 200 OK")
				.extract().response();
			
			String responsebody=response.getBody().asString();
			System.out.println("Response"+responsebody);
			
			JSONParser parse=new JSONParser();
			JSONArray arr=(JSONArray) parse.parse(responsebody);
			String id="";
			for(int i=0;i<arr.size();i++) {
				
				JSONObject obj=(JSONObject) arr.get(i);
				
				if(i==0) {
					id=(String) obj.get("id");
					break;
				}
			}
		
			System.out.println("id is"+id);
				given()
				.filter(new AllureRestAssured())
					.baseUri("https://sreesumaa.herokuapp.com")
					.pathParam("id", id)
				.when()
					.delete("/transactions/{id}")
				.then()
					.statusCode(204)
					.log().all();
	}catch(Exception ex) {
		ex.printStackTrace();
			
	}
	}

	@Test(priority = 2)
	@Story("Delete Request")
    @Severity(SeverityLevel.NORMAL)
    @Description("Test Description : Delete Method With InCorrect Id In List Of Transactions")
	public void deleteMethodWithIncorrectId() {
		
		given()
		.filter(new AllureRestAssured())
			.baseUri("https://sreesumaa.herokuapp.com")
			.pathParam("id", "e9d1ac8-7bc8-43a7-87bf-d438fbbe1566")
		.when()
			.delete("/transactions/{id}")
		.then()
			.statusCode(404)
			.body("message",equalTo("Transaction not found"))
			.log().all();
			
	}
}

