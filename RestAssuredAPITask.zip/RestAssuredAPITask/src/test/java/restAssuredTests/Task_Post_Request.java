package restAssuredTests;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItems;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.qameta.allure.*;
import io.qameta.allure.restassured.AllureRestAssured;
import io.restassured.http.ContentType;
@Epic("REST API Regression Testing using TestNG")
@Feature("Verify CRUD Operations")
public class Task_Post_Request {
	
		
		@Test
        @Story("Post Request")
	    @Severity(SeverityLevel.NORMAL)
	    @Description("Test Description : Post Method To Create A Transaction")

		public void postMethod() {
			
			JSONObject request=new JSONObject();
			
			request.put("name", "Pizza Pizza");
			request.put("type", "Expense");
			request.put("category", "Food");
			request.put("value", 20.9);
			request.put("date", "2022-05-25T02022-05-31");

			
			System.out.println("Body parameters are"+request.toJSONString());
			
			given()
			.filter(new AllureRestAssured())
				.baseUri("https://sreesumaa.herokuapp.com")
				.body(request.toJSONString())
				.header("Content-Type", "application/json")
				.contentType(ContentType.JSON)
				.accept(ContentType.JSON)
			.when()
				.post("/transactions")
			.then()
				.statusCode(201)
				.log().all();
		}

	}

